CFD - 5 kN cold-gas nozzle, OpenFOAM v2512 rhoCentralFoam (set up in SimFlow 5.1)
coldgas_nozzle_rhoCentralFoam/   complete case: mesh (5 deg wedge, 25,360 cells), 0/ initial and boundary
                                 conditions (plenum patched to 100 bar), constant/, system/,
                                 results at t = 0.3 ms (0.0003/, binary) and the solver log
  Run (Linux/OpenFOAM v2512):  cd coldgas_nozzle_rhoCentralFoam && rhoCentralFoam > log 2>&1
  View: open case.foam in ParaView.
  Note: thermophysicalProperties uses energy sensibleInternalEnergy (required by rhoCentralFoam).
foam.py, plot_cfd.py   Read the OpenFOAM fields and reproduce the Mach/temperature plots and the
                       exit-plane thrust and mass-flow integration:  python plot_cfd.py <case> 0.0003
