import numpy as np, re, gzip, os
def _body(path):
    op = gzip.open if path.endswith('.gz') else open
    t = op(path, 'rt').read()
    t = re.sub(r'/\*.*?\*/', '', t, flags=re.S)
    i = t.index('FoamFile'); j = t.index('}', i)
    return t[j+1:]
def _list(t):
    m = re.search(r'(\d+)\s*\(', t); n = int(m.group(1)); return n, t[m.end():]
def points(d):
    n, t = _list(_body(f'{d}/points'))
    a = np.array([x.split() for x in re.findall(r'\(([^()]+)\)', t)[:n]], float); return a
def faces(d):
    n, t = _list(_body(f'{d}/faces'))
    return [list(map(int, f.split())) for f in re.findall(r'\d+\(([^()]+)\)', t)[:n]]
def labels(path):
    n, t = _list(_body(path)); return np.array(t.split(')')[0].split()[:n], int)
def centres(d):
    P = points(d); F = faces(d); own = labels(f'{d}/owner'); nei = labels(f'{d}/neighbour')
    nc = max(own.max(), nei.max()) + 1
    s = np.zeros((nc, 3)); c = np.zeros(nc)
    fc = np.array([P[f].mean(axis=0) for f in F])
    np.add.at(s, own, fc); np.add.at(c, own, 1)
    np.add.at(s, nei, fc[:len(nei)]); np.add.at(c, nei, 1)
    return s / c[:, None]
def field(path, n):
    t = _body(path); i = t.index('internalField'); t = t[i:]
    if t.startswith('internalField   uniform') or re.match(r'internalField\s+uniform', t):
        v = re.match(r'internalField\s+uniform\s+(\([^)]*\)|\S+);', t).group(1)
        v = np.array(v.strip('()').split(), float); return np.tile(v, (n, 1)).squeeze()
    m = re.search(r'nonuniform\s+List<(\w+)>\s*(\d+)\s*\(', t); k = int(m.group(2)); t = t[m.end():]
    if m.group(1) == 'vector':
        return np.array([x.split() for x in re.findall(r'\(([^()]+)\)', t)[:k]], float)
    return np.array(t.split(')')[0].split()[:k], float)

def field_any(path, n):
    raw = open(path, 'rb').read()
    i = raw.index(b'internalField')
    seg = raw[i:i+200]
    if b'nonuniform' not in raw[i:i+60]:
        return field(path, n)
    m = re.search(rb'nonuniform\s+List<(\w+)>\s*(\d+)\s*\(', raw[i:])
    kind = m.group(1); k = int(m.group(2)); st = i + m.end()
    nc = 3 if kind == b'vector' else 1
    # binary if format binary in header
    if b'format      binary' in raw[:2000] or re.search(rb'format\s+binary', raw[:2000]):
        a = np.frombuffer(raw[st:st+8*nc*k], dtype='<f8')
        return a.reshape(k, nc) if nc == 3 else a
    return field(path, n)
