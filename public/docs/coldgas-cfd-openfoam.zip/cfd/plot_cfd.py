import sys, math, numpy as np, foam, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation
from matplotlib.colors import LinearSegmentedColormap
case = sys.argv[1]; tdir = sys.argv[2]
C = foam.centres(f'{case}/constant/polyMesh'); x = C[:,0]*1e3; r = np.hypot(C[:,1], C[:,2])*1e3; n = len(C)
p = foam.field_any(f'{case}/{tdir}/p', n); T = foam.field_any(f'{case}/{tdir}/T', n); U = foam.field_any(f'{case}/{tdir}/U', n)
R, g = 287.0, 1.4
Ma = np.linalg.norm(U, axis=1)/np.sqrt(g*R*T); rho = p/(R*T)
rc, rt, re_ = 30.0, 10.14, 28.76
Lc = (rc-rt)/math.tan(math.radians(30)); Ld = (re_-rt)/math.tan(math.radians(15)); Le = Lc+Ld
def wall(xx): return np.where(xx<=0, rc, np.where(xx<=Lc, rc+(rt-rc)*xx/Lc, np.where(xx<=Le, rt+(re_-rt)*(xx-Lc)/Ld, np.inf)))
# mirror for full nozzle picture
X = np.concatenate([x, x]); Rr = np.concatenate([r, -r])
tri = Triangulation(X, Rr)
cx = X[tri.triangles].mean(1); cr = np.abs(Rr[tri.triangles]).mean(1)
mask = cr > wall(cx) - 0.05
# also mask triangles bridging across the axis spuriously long
edges = np.max(np.hypot(np.diff(X[tri.triangles][:, [0,1,2,0]],axis=1), np.diff(Rr[tri.triangles][:, [0,1,2,0]],axis=1)), axis=1)
mask |= edges > 12
tri.set_mask(mask)
ramp = ['#E6F6F6','#B3E6E6','#66CCCC','#00A6A6','#007A7A','#1F4E6B','#102A43']
seq = LinearSegmentedColormap.from_list('teal', ramp)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.edgecolor':'#9FB3C8','axes.labelcolor':'#334E68','xtick.color':'#627D98','ytick.color':'#627D98'})
fig, axs = plt.subplots(2, 1, figsize=(12, 8.2), sharex=True)
xs = np.r_[-40, 0, Lc, Le]; ws = [rc, rc, rt, re_]
for ax, F, lab, lev, cm in [(axs[0], np.concatenate([Ma,Ma]), 'Mach number', np.linspace(0, 5.6, 29), seq),
                            (axs[1], np.concatenate([T,T]), 'Static temperature (K)', np.linspace(40, 320, 29), seq.reversed())]:
    cs = ax.tricontourf(tri, F, levels=lev, cmap=cm, extend='both')
    for sgn in (1,-1): ax.plot(xs, sgn*np.array(ws), color='#102A43', lw=2.2, solid_capstyle='butt')
    ax.set_aspect('equal'); ax.set_ylabel('r (mm)'); ax.set_xlim(-40, 260); ax.set_ylim(-80, 80)
    for s_ in ('top','right'): ax.spines[s_].set_visible(False)
    cb = fig.colorbar(cs, ax=ax, shrink=0.9, pad=0.015); cb.set_label(lab); cb.outline.set_visible(False)
axs[1].set_xlabel('x (mm), nozzle inlet at 0, exit at %.0f' % Le)
fig.savefig('cfd-nozzle.png', dpi=160, bbox_inches='tight', facecolor='white')
# axis line vs isentropic
ax_m = r < 1.5; o = np.argsort(x[ax_m]); xa = x[ax_m][o]; Ma_a = Ma[ax_m][o]; T_a = T[ax_m][o]
def M_of_AR(ar, sup):
    from scipy.optimize import brentq
    f = lambda M: (1/M)*((2/(g+1))*(1+(g-1)/2*M*M))**((g+1)/(2*(g-1))) - ar
    return brentq(f, 1.0001, 10) if sup else brentq(f, 1e-4, 0.9999)
xi = np.linspace(0, Le, 120); Mi = [M_of_AR((wall(np.array([q]))[0]/rt)**2, q > Lc) for q in xi]
# exit plane
cand = (x < Le) & (x > Le-3) & (r < re_)
xlast = x[cand].max(); k = cand & (np.abs(x - xlast) < 0.2)
print('exit cells', k.sum(), 'at x', xlast)
def avg(v): w = r[k]; return np.sum(v[k]*w)/np.sum(w)
# thrust: momentum + pressure over exit plane, axisymmetric
order = np.argsort(r[k]); rr = r[k][order]*1e-3; rb = np.r_[0, (rr[1:]+rr[:-1])/2, re_*1e-3]; dA = math.pi*(rb[1:]**2-rb[:-1]**2)
Fx = np.sum((rho[k][order]*U[k][order,0]**2 + p[k][order]-101325)*dA)
mdot = np.sum(rho[k][order]*U[k][order,0]*dA)
res = dict(Ma_exit=avg(Ma), T_exit=avg(T), p_exit=avg(p), Ma_max=Ma.max(), T_min=T.min(), thrust=Fx, mdot=mdot, ve=Fx/mdot,
           Ma_axis_exit=float(np.interp(Le, xa, Ma_a)), T_axis_exit=float(np.interp(Le, xa, T_a)))
print({k_: round(float(v),3) for k_, v in res.items()})
fig, ax = plt.subplots(figsize=(8, 3.6))
ax.plot(xi, Mi, color='#9FB3C8', lw=2, ls='--', label='1D isentropic theory')
ax.plot(xa, Ma_a, color='#007A7A', lw=2, label='CFD, on axis')
ax.axvline(Le, color='#D9E2EC', lw=1); ax.text(Le+3, 0.2, 'exit', color='#627D98', fontsize=10)
ax.set_xlim(-40, 260); ax.set_xlabel('x (mm)'); ax.set_ylabel('Mach number')
for s_ in ('top','right'): ax.spines[s_].set_visible(False)
ax.legend(frameon=False, loc='upper left')
fig.savefig('cfd-axis.png', dpi=160, bbox_inches='tight', facecolor='white')
import json; json.dump({k_: float(v) for k_, v in res.items()}, open('cfd_res.json','w'))
