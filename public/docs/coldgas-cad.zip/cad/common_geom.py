# Shared 2D section geometry for the COPV (mm). X = radial, Y = axis.
import Part
from FreeCAD import Vector as V
import math
RI, TL, TC = 415.0, 3.0, 26.0          # inner radius, liner, CF overwrap
ROL = RI + TL; RO = ROL + TC
THF = math.radians(10.4)               # boss flange half-angle at pole
RN, HN = 35.0, 45.0                    # neck radius / height above OD
RB = 12.0                              # port bore radius
YB_END = RO + HN - 15.0                # blind bore end (valve seat)
def disk(R): return Part.Face(Part.Wire(Part.makeCircle(R)))
def rect(x0, y0, x1, y1):
    p = [V(x0,y0,0),V(x1,y0,0),V(x1,y1,0),V(x0,y1,0),V(x0,y0,0)]
    return Part.Face(Part.makePolygon(p))
def ann(r1, r2): return disk(r2).cut(disk(r1))
def cone(th, L=2000.0):
    return Part.Face(Part.makePolygon([V(0,0,0),V(L*math.sin(th),L*math.cos(th),0),V(0,L,0),V(0,0,0)]))
def faces_of(s):
    s = s.removeSplitter() if hasattr(s,'removeSplitter') else s
    return s
def section():
    H = rect(0, -600, 600, 600)
    neck = rect(0, 400, RN, RO + HN)
    bore = rect(0, 0, RB, YB_END)
    flange = ann(RI, ROL + TC/2).common(cone(THF))
    boss = flange.fuse(neck).cut(bore).common(H)
    liner = ann(RI, ROL).common(H).cut(cone(THF))
    cf = ann(ROL, RO).common(H).cut(flange).cut(neck).cut(bore)
    return faces_of(liner), faces_of(boss), faces_of(cf)
