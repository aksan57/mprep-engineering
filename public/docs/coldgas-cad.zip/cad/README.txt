CAD - cold-gas thruster study (units: mm; tank axis = Y, nozzle axis = Y in STEP)
copv_tank_450bar.step        3D tank: liner (Al 6061-T6), overwrap (CFRP), boss (Ti-6Al-4V) as separate bodies
copv_axisym_section.step     2D axisymmetric half-section used for the FEA (faces share edges)
coldgas_nozzle_5kN.step/.stl Conical convergent-divergent nozzle with flange (throat 20.3 mm, exit 57.5 mm)
tesla_coldgas_cad.FCStd      FreeCAD 1.1 document
01_tesla_cad.FCMacro + common_geom.py   FreeCAD macro that rebuilds the geometry
build_cad_cadquery.py        CadQuery script that rebuilds and exports the STEP files
