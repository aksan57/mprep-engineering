import math, cadquery as cq
from cadquery import Face, Wire, Vector as V, Compound, Solid
from OCP.BOPAlgo import BOPAlgo_Builder
from OCP.TopTools import TopTools_ListOfShape
RI, TL, TC = 415.0, 3.0, 26.0; ROL = RI+TL; RO = ROL+TC
THF = math.radians(10.4); RN, HN, RB = 35.0, 45.0, 12.0; YB_END = RO+HN-15.0
def disk(R): return Face.makeFromWires(Wire.makeCircle(R, V(0,0,0), V(0,0,1)))
def poly(pts): return Face.makeFromWires(Wire.makePolygon([V(x,y,0) for x,y in pts], close=True))
def rect(x0,y0,x1,y1): return poly([(x0,y0),(x1,y0),(x1,y1),(x0,y1)])
def ann(r1,r2): return disk(r2).cut(disk(r1))
def cone(th,L=2000.): return poly([(0,0),(L*math.sin(th),L*math.cos(th)),(0,L)])
H = rect(0,-600,600,600); neck = rect(0,400,RN,RO+HN); bore = rect(0,0,RB,YB_END)
flange = ann(RI, ROL+TC/2).intersect(cone(THF))
boss = flange.fuse(neck).cut(bore).intersect(H).clean()
liner = ann(RI,ROL).intersect(H).cut(cone(THF)).clean()
cf = ann(ROL,RO).intersect(H).cut(flange).cut(neck).cut(bore).clean()
for n,s in (("liner",liner),("boss",boss),("cf",cf)): print(n, "area mm2", round(s.Area()), "faces", len(s.Faces()))
# conformal 2D fragments
b = BOPAlgo_Builder()
for s in (liner,boss,cf): b.AddArgument(s.wrapped)
b.Perform(); frag = cq.Shape.cast(b.Shape())
print("fragment faces", len(frag.Faces()), "edges", len(frag.Edges()))
cq.exporters.export(frag, "copv_axisym_section.step")
# 3D revolve
def rev(f, ang=360): return Solid.revolve(f, ang, V(0,0,0), V(0,1,0))
asm = cq.Assembly()
cols = {"Liner_Al6061":(0.8,0.8,0.82),"Boss_Ti6Al4V":(0.55,0.58,0.62),"Overwrap_CFRP":(0.12,0.12,0.13)}
solids = {}
for (n,f) in (("Liner_Al6061",liner),("Boss_Ti6Al4V",boss),("Overwrap_CFRP",cf)):
    s = Compound.makeCompound([rev(ff) for ff in f.Faces()]); solids[n]=s
    asm.add(s, name=n, color=cq.Color(*cols[n]))
asm.save("copv_tank_450bar.step")
# nozzle
rc, rt, re = 30.0, 10.14, 28.76
Lc=(rc-rt)/math.tan(math.radians(30)); Ld=(re-rt)/math.tan(math.radians(15))
pts=[(rc,0),(60,0),(60,10),(rc+6,10),(rt+6,Lc),(re+4,Lc+Ld),(re,Lc+Ld),(rt,Lc)]
prof = poly(pts)
noz = Solid.revolve(prof, 360, V(0,0,0), V(0,1,0))
cq.exporters.export(noz, "coldgas_nozzle_5kN.step")
cq.exporters.export(noz, "coldgas_nozzle_5kN.stl")
print("nozzle vol cm3", noz.Volume()/1e3, "Lc", Lc, "Ld", Ld)
# cutaway for illustration
cut = Compound.makeCompound([Solid.revolve(ff,270,V(0,0,0),V(0,1,0)) for f in (liner,boss,cf) for ff in f.Faces()])
cq.exporters.export(cut, "copv_cutaway.stl", tolerance=0.3, angularTolerance=0.1)
for n,s in solids.items(): cq.exporters.export(s, f"cut_{n}.stl", tolerance=0.3, angularTolerance=0.1)
import pickle
for n,f in (("liner",liner),("boss",boss),("cf",cf)):
    cq.exporters.export(Compound.makeCompound([Solid.revolve(ff,270,V(0,0,0),V(0,1,0)) for ff in f.Faces()]), f"cut270_{n}.stl", tolerance=0.3, angularTolerance=0.1)
