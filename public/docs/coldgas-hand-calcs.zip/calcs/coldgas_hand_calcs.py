"""MPrep Engineering - cold-gas thruster case study: hand calculations.
Reproduces every hand-calculated number on the case-study page.
Requires: numpy, scipy, CoolProp  (pip install numpy scipy CoolProp)
All dimensions are MPrep's own design assumptions, not Tesla data.
"""
import math
import numpy as np
import CoolProp.CoolProp as CP

R, g = 287.05, 1.4
cp = g * R / (g - 1)

# ---------- 1. Gas budget (real gas, Lemmon et al. 2000 via CoolProp) ----------
V_total, m_air, T0 = 0.600, 250.0, 300.0
rho_need = m_air / V_total
p_need = CP.PropsSI('P', 'D', rho_need, 'T', T0, 'Air')
rho_379 = CP.PropsSI('D', 'P', 379.2e5, 'T', T0, 'Air')
print(f"Pressure for 250 kg in 600 L at 300 K : {p_need/1e5:.0f} bar")
print(f"Mass in 600 L at 5,500 psi (379 bar)  : {rho_379*V_total:.0f} kg (Z = {379.2e5/(rho_379*R*T0):.3f})")
print(f"Ideal-gas mass at 379 bar             : {379.2e5/(R*T0)*V_total:.0f} kg")
h, s = CP.PropsSI('H', 'P', 450e5, 'T', T0, 'Air'), CP.PropsSI('S', 'P', 450e5, 'T', T0, 'Air')
h0, s0 = CP.PropsSI('H', 'P', 101325, 'T', T0, 'Air'), CP.PropsSI('S', 'P', 101325, 'T', T0, 'Air')
print(f"Minimum (exergy) work, 250 kg @ 450 bar: {((h-h0)-T0*(s-s0))*m_air/3.6e6:.1f} kWh")

# ---------- 2. Tank (two-layer sphere, equal biaxial strain) ----------
ri, tl, tc = 415.0, 3.0, 26.0            # mm
rl, ro = ri + tl, ri + tl + tc
p_w, BF = 45.0, 2.25                      # MPa
Ea, na, Ec, nc = 69e3, 0.33, 50e3, 0.30   # MPa
t_size = p_w * BF * ri / (2 * 800.0)      # thin-wall sizing to 800 MPa at burst
eps = p_w * ri**2 / (Ea/(1-na)*(rl**2-ri**2) + Ec/(1-nc)*(ro**2-rl**2))  # equator force balance
s_al, s_cf = Ea/(1-na)*eps, Ec/(1-nc)*eps
print(f"Overwrap thickness for 800 MPa at burst: {t_size:.1f} mm (26 mm used)")
print(f"Membrane stress: liner {s_al:.0f} MPa, overwrap {s_cf:.0f} MPa; overwrap at burst {s_cf*BF:.0f} MPa")
print(f"Radial growth at OD: {eps*ro:.2f} mm")
m_cf = 4/3*math.pi*(ro**3-rl**3)*1e-9*1550; m_al = 4/3*math.pi*(rl**3-ri**3)*1e-9*2700
print(f"Shell mass, two tanks: {2*(m_cf+m_al):.0f} kg (composite {2*m_cf:.0f}, liner {2*m_al:.0f})")

# Quasi-isotropic laminate from published ITS50/epoxy ply data (Rocha et al. 2024, Table 1)
E1, E2, v12, G12, Xt = 134.8e3, 6.5e3, 0.30, 6.0e3, 2097.0
v21 = v12*E2/E1; d = 1 - v12*v21
Q = np.array([[E1/d, v12*E2/d, 0], [v12*E2/d, E2/d, 0], [0, 0, G12]])
def Qbar(th):
    c, s_ = math.cos(math.radians(th)), math.sin(math.radians(th))
    T = np.array([[c*c, s_*s_, 2*s_*c], [s_*s_, c*c, -2*s_*c], [-s_*c, s_*c, c*c-s_*s_]])
    Rr = np.diag([1, 1, 2]); return np.linalg.inv(T) @ Q @ Rr @ T @ np.linalg.inv(Rr)
A = sum(Qbar(t) for t in (0, 45, -45, 90)) / 4
print(f"[0/45/-45/90] laminate: E = {(A[0,0]*A[1,1]-A[0,1]**2)/A[1,1]/1e3:.1f} GPa, "
      f"equibiaxial fibre-failure stress = {(A[0,0]+A[0,1])*Xt/(Q[0,0]+Q[0,1]):.0f} MPa")

# ---------- 3. Nozzle (1D isentropic, Sutton & Biblarz ch. 3) ----------
pc, pa, F = 100e5, 101325.0, 5000.0
Me = math.sqrt(2/(g-1)*((pc/pa)**((g-1)/g)-1))
AR = 1/Me*((2/(g+1))*(1+(g-1)/2*Me**2))**((g+1)/(2*(g-1)))
Te = T0/(1+(g-1)/2*Me**2); ve = Me*math.sqrt(g*R*Te)
CF = math.sqrt(2*g**2/(g-1)*(2/(g+1))**((g+1)/(g-1))*(1-(pa/pc)**((g-1)/g)))
At = F/(CF*pc); mdot = At*pc*math.sqrt(g/(R*T0))*(2/(g+1))**((g+1)/(2*(g-1)))
print(f"Me {Me:.2f}, Ae/At {AR:.2f}, Te {Te:.1f} K, ve {ve:.0f} m/s, Isp {ve/9.80665:.0f} s, CF {CF:.3f}")
print(f"Throat {math.sqrt(4*At/math.pi)*1e3:.1f} mm, exit {math.sqrt(4*At*AR/math.pi)*1e3:.1f} mm, mdot {mdot:.2f} kg/s")
print(f"15 deg cone divergence factor: {(1+math.cos(math.radians(15)))/2:.3f} -> {ve*(1+math.cos(math.radians(15)))/2:.0f} m/s")
print(f"Dew point of air at 1 atm: {CP.PropsSI('T','P',101325,'Q',1,'Air'):.1f} K")
print(f"Total impulse of 250 kg at ve: {m_air*ve/1e3:.0f} kN s; four nozzles empty it in {m_air/(4*mdot):.1f} s")
