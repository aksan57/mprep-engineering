coldgas_hand_calcs.py  Reproduces every hand-calculated number on the page: real-gas air budget
(CoolProp / Lemmon et al. 2000), tank membrane stresses and mass, quasi-isotropic laminate check,
1D isentropic nozzle sizing, divergence loss, dew point and total impulse.
pip install numpy scipy CoolProp ; python coldgas_hand_calcs.py
