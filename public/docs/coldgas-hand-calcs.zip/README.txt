MPrep Engineering - Case study 02: Cold-gas thruster air tank & nozzle
https://mprep-engineering.vercel.app/projects/cold-gas-thruster/

All geometry, materials and loads are MPrep's own design assumptions built around
press-reported figures (about 600 L and 250 kg of air). Nothing here is a Tesla design.
Conceptual study only: not fabricated, tested or code-verified. Free to reuse with attribution.
Units: mm, MPa, tonne-mm-s (FEA); SI (CFD and calculations).
