import numpy as np, math, re, sys
# usage: python build_inp_from_mesh.py <gmsh_cax6_mesh.inp> [pressure_MPa]
src = sys.argv[1]
RI, TL, TC = 415.0, 3.0, 26.0; ROL=RI+TL; RO=ROL+TC
THF=math.radians(10.4); RN, HN, RB = 35.0, 45.0, 12.0; YB=RO+HN-15.0
P = float(sys.argv[2]) if len(sys.argv)>2 else 45.0
L = open(src).read().splitlines()
i = L.index("*Node")+1; nodes={}
while not L[i].startswith("*"):
    if L[i].strip() and not L[i].startswith("**"):
        a=L[i].split(","); nodes[int(a[0])]=(float(a[1]),float(a[2]))
    i+=1
j = next(k for k,l in enumerate(L) if l.startswith("*Element")); j+=1; els={}
while not L[j].startswith("*"):
    a=[int(x) for x in L[j].split(",") if x.strip()]; els[a[0]]=a[1:]; j+=1
print(len(nodes),"nodes",len(els),"elements")
X=np.array([nodes[k] for k in sorted(nodes)])
# conformity: duplicate coordinates?
u=np.unique(np.round(X,4),axis=0); print("duplicate node coords:",len(X)-len(u))
sets={"LINER":[],"BOSS":[],"CF":[]}
def region(x,y):
    r=math.hypot(x,y); th=math.atan2(x,y)
    if (x<RN and y>400) : return "BOSS"
    if th<THF and r<ROL+TC/2: return "BOSS"
    if r<ROL: return "LINER"
    return "CF"
for e,n in els.items():
    c=np.mean([nodes[k] for k in n[:3]],axis=0); sets[region(*c)].append(e)
print({k:len(v) for k,v in sets.items()})
def onP(x,y):
    r=math.hypot(x,y)
    if r<RI+0.3 and x>1e-6: return True
    if abs(r-RI)<0.3: return True
    if abs(x-RB)<0.01 and y>RI-20 and y<=YB+1e-3: return True
    if abs(y-YB)<0.01 and x<=RB+1e-3: return True
    return False
import collections
cnt=collections.Counter()
for e,n in els.items():
    for a,b in ((0,1),(1,2),(2,0)): cnt[tuple(sorted((n[a],n[b])))]+=1
faces={1:[],2:[],3:[]}
for e,n in els.items():
    for f,(a,b,m) in {1:(0,1,3),2:(1,2,4),3:(2,0,5)}.items():
        if cnt[tuple(sorted((n[a],n[b])))]==1 and onP(*nodes[n[a]]) and onP(*nodes[n[b]]) and onP(*nodes[n[m]]): faces[f].append(e)
print("pressure faces:",{k:len(v) for k,v in faces.items()})
fix=min(nodes,key=lambda k:(nodes[k][0])**2+(nodes[k][1]+RO)**2); print("fix node",fix,nodes[fix])
head="\n".join(L[:j])  # nodes + elements
def chunk(ids): 
    ids=sorted(ids); return "\n".join(", ".join(map(str,ids[k:k+16])) for k in range(0,len(ids),16))
out=[head]
for k,v in sets.items(): out.append(f"*Elset, Elset={k}\n{chunk(v)}")
for f,v in faces.items():
    if v: out.append(f"*Elset, Elset=PFACE_S{f}\n{chunk(v)}")
out.append("*Surface, Name=INNER_P, Type=Element\n"+"\n".join(f"PFACE_S{f}, S{f}" for f,v in faces.items() if v))
out.append(f"*Nset, Nset=POLE_FIX\n{fix}")
out.append("""*Material, Name=Al6061-T6
*Density
2.7E-09
*Elastic
69000, 0.33
*Material, Name=Ti-6Al-4V
*Density
4.43E-09
*Elastic
114000, 0.34
*Material, Name=CFRP-QI
*Density
1.55E-09
*Elastic
50000, 0.3
*Solid section, Elset=LINER, Material=Al6061-T6
*Solid section, Elset=BOSS, Material=Ti-6Al-4V
*Solid section, Elset=CF, Material=CFRP-QI
*Boundary
POLE_FIX, 2, 2, 0
*Step
*Static
*Dsload
INNER_P, P, %g
*Node file
U, RF
*El file
S, E
*End step""" % P)
open(f"copv_axisym_{int(P)}MPa.inp","w").write("\n".join(out)+"\n")
