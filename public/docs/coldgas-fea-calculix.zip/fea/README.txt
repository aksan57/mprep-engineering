FEA - 2D axisymmetric COPV at 45 MPa (CalculiX 2.22 via PrePoMax 2.6.2)
copv_axisym_45MPa.inp          CalculiX input deck (CAX6, 3 materials, 45 MPa on inner surface and port)
                               Run:  ccx -i copv_axisym_45MPa
copv_axisym_45MPa.frd          Results (displacement, stress, strain) as solved for the case study
copv_axisym_45MPa_prepomax.pmx PrePoMax model
build_inp_from_mesh.py         Builds the deck from a Gmsh/FreeCAD CAX6 mesh (element sets, pressure faces, BCs)
frd.py, plot_fea_site.py       Read the .frd and plot von Mises contours (matplotlib)
Units: mm, N, MPa. Materials: Al 6061-T6 E=69 GPa nu=0.33; Ti-6Al-4V E=114 GPa nu=0.34;
CFRP quasi-isotropic E=50 GPa nu=0.30 (isotropic approximation - see limitations on the page).
