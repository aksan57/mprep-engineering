import numpy as np
def _vals(s, start=13, w=12):
    s=s.rstrip("\n"); out=[]
    k=start
    while k+w<=len(s):
        out.append(float(s[k:k+w])); k+=w
    return out
def read_frd(path):
    nodes={}; blocks={}
    lines=open(path).readlines(); i=0
    while i<len(lines):
        l=lines[i]
        if l.startswith("    2C"):
            i+=1
            while not lines[i].startswith(" -3"):
                s=lines[i]; v=_vals(s); nodes[int(s[3:13])]=v; i+=1
        elif l.startswith(" -4"):
            name=l[5:13].strip(); data={}; i+=1
            while lines[i].startswith(" -5"): i+=1
            while not lines[i].startswith(" -3"):
                s=lines[i]
                if s.startswith(" -1"): data[int(s[3:13])]=_vals(s)
                i+=1
            blocks[name]=data
        i+=1
    return nodes,blocks
