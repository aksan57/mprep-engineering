import numpy as np, pickle, math, re, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.tri import Triangulation
# usage: python plot_fea_site.py copv_axisym_45MPa.inp copv_axisym_45MPa.frd
import sys
from frd import read_frd
n,b=read_frd(sys.argv[2]); S=b['STRESS']
L=open(sys.argv[1]).read().splitlines()
j=next(k for k,l in enumerate(L) if l.startswith('*Element'))+1; els=[]
while not L[j].startswith('*'):
    a=[int(x) for x in L[j].split(',') if x.strip()]; els.append(a[1:]); j+=1
ids=sorted(n); idx={k:i for i,k in enumerate(ids)}
X=np.array([n[k][0] for k in ids]); Y=np.array([n[k][1] for k in ids])
def vm(s):
    sx,sy,sz,txy,tyz,tzx=s
    return math.sqrt(0.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy**2+tyz**2+tzx**2))
V=np.array([vm(S[k]) for k in ids])
# split each tri6 into 4 linear tris
T=[]
for e in els:
    a,b_,c,d,e_,f=[idx[k] for k in e]
    T+= [(a,d,f),(d,b_,e_),(f,e_,c),(d,e_,f)]
tri=Triangulation(X,Y,np.array(T))
ramp=['#E6F6F6','#B3E6E6','#66CCCC','#00A6A6','#007A7A','#1F4E6B','#102A43']
cmap=LinearSegmentedColormap.from_list('seqblue',ramp)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.edgecolor':'#9FB3C8','axes.labelcolor':'#334E68','xtick.color':'#627D98','ytick.color':'#627D98'})
fig,axs=plt.subplots(1,2,figsize=(12,6.6),gridspec_kw={'width_ratios':[1,1.15]})
lev=np.linspace(0,700,29)
for ax,(xl,yl),title in [(axs[0],((-10,470),(-470,510)),'Full section (axisymmetric, axis at r = 0)'),(axs[1],((0,130),(380,500)),'Polar boss region (zoom)')]:
    cs=ax.tricontourf(tri,np.clip(V,0,700),levels=lev,cmap=cmap,extend='max')
    ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect('equal'); ax.set_title(title,fontsize=12,color='#102A43',loc='left')
    ax.set_xlabel('r (mm)'); ax.set_ylabel('z (mm)')
    for s in ('top','right'): ax.spines[s].set_visible(False)
# annotations on zoom
ax=axs[1]
for (x,y,t,dx,dy) in [(90,405.2,'Liner beside boss\n≈530 MPa',-5,-22),(60,436,'Overwrap\n≈300 MPa',35,22),(35.5,413.5,'Re-entrant corner\n(singular peak)',-30,-26)]:
    ax.annotate(t,(x,y),(x+dx,y+dy),fontsize=9.5,color='#102A43',arrowprops=dict(arrowstyle='-',color='#334E68',lw=0.8))
cb=fig.colorbar(cs,ax=axs,shrink=0.85,pad=0.02); cb.set_label('von Mises stress at 450 bar (MPa)'); cb.outline.set_visible(False)
pass
fig.savefig('copv-vonmises.png',dpi=160,bbox_inches='tight',facecolor='white')
print("saved; max V",V.max())
